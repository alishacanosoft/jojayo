<?php $__env->startSection('content'); ?>
<div class="ps-page--blog">
      <div class="container">
        <div class="ps-page__header">
          <h1>Our Blogs</h1>
          <div class="ps-breadcrumb--2">
            <ul class="breadcrumb">
              <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li>Our Blogs</li>
            </ul>
          </div>
        </div>
        <div class="ps-blog--sidebar">
          <div class="ps-blog__left">
          <?php if(!empty($allPosts)): ?>
          <?php $__currentLoopData = $allPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ps-post ps-post--small-thumbnail">
              <div class="ps-post__thumbnail"><a class="ps-post__overlay" href="<?php echo e(url('/blogs/'.$post->slug)); ?>"></a><img src="<?php echo e(url('/uploads/blogs/'.$post->image)); ?>" alt="<?php echo e($post->slug); ?>">
                <?php if($post->feature==1): ?>
                <div class="ps-post__badge"><i class="icon-star"></i></div>
                <?php endif; ?>
              </div>
              <div class="ps-post__content">
                <div class="ps-post__top">
                  <div class="ps-post__meta"><a href="<?php echo e(url('/blogs/categories/'.$post->category->slug)); ?>"><?php echo e(ucwords($post->category->name)); ?></a>
                  </div><a class="ps-post__title" href="<?php echo e(url('/blogs/'.$post->slug)); ?>"><?php echo e(ucwords($post->title)); ?></a>
                 
                  <p>  <?php echo e(ucfirst($post->excerpt)); ?> </p>
                </div>
                <div class="ps-post__bottom">
                  <p><?php echo e($post->created_at->format('F  j, Y')); ?></p>
                </div>
              </div>
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
            <div class="ps-pagination">
            <?php echo e($allPosts->links()); ?>  
            </div>
          </div>

          <div class="ps-blog__right">
                <?php echo $__env->make('frontend.pages.blog-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>            
          </div>
        </div>
      </div>
</div>
<div class="related-products"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/frontend/pages/blogs.blade.php ENDPATH**/ ?>