<option selected disabled>--Select Transaction Date--</option>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(date('d', strtotime($row->order_created)) > 14 && date('d', strtotime($row->order_created)) <= 21): ?>{
<option value="<?php echo e(date('Y-m-15')); ?>"><?php echo e(date('15 F Y',strtotime($row->order_created)).' - '.date('21 F Y',strtotime($row->order_created))); ?></option>
<?php elseif(date('d', strtotime($row->order_created)) > 21 && date('d', strtotime($row->order_created)) <= 28): ?>
<option value="<?php echo e(date('Y-m-21')); ?>"><?php echo e(date('21 F Y',strtotime($row->order_created)).' - '.date('28 F Y',strtotime($row->order_created))); ?></option>
<?php elseif(date('d', strtotime($row->order_created)) > 7 && date('d', strtotime($row->order_created)) <= 14): ?>
<option value="<?php echo e(date('Y-m-8')); ?>"><?php echo e(date('8 F Y',strtotime($row->order_created)).' - '.date('14 F Y',strtotime($row->order_created))); ?></option>
<?php elseif(date('d', strtotime($row->order_created)) <= 7): ?>
<option value="<?php echo e(date('Y-m-7')); ?>"><?php echo e(date('1 F Y',strtotime($row->order_created)).' - '.date('7 F Y',strtotime($row->order_created))); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/admin/pages/ajax/date.blade.php ENDPATH**/ ?>