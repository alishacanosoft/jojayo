<?php $__env->startSection('styles'); ?>
<style>
ul.ps-countdown{
    padding: 0px 0px 0px 5px
}
.ps-block__right .text-dark{
    font-size: 14px;
    font-weight: 500
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row text-left pt-10">        
        <div class="ps-container">
            <div class="ps-section__header">
                <div class="ps-block--countdown-deal">                    
                    <div class="ps-block__right">
                    <?php if(!empty($flash) && count($flash) > 0): ?>
                        <figure>
                            <figcaption>Current sale Ends in:</figcaption>
                            <ul class="ps-countdown" data-time="<?php echo e(date('F d, Y')); ?> <?php echo e($end_time); ?>">
                                <!--<li><span class="days"></span></li>-->
                                <li><span class="hours"></span></li> <span class="text-dark bold">:</span>
                                <li><span class="minutes"></span></li> <span class="text-dark bold">:</span>
                                <li><span class="seconds"></span></li>
                            </ul>
                            <a href="#today11" class="text-dark today11" <?php if(date('H') > 11): ?> hidden <?php endif; ?>>&nbsp; &nbsp; 11:00 &nbsp; |</a>
                            <a href="#today15" class="text-dark today15" <?php if(date('H') > 15): ?> hidden <?php endif; ?>>&nbsp; &nbsp; 15:00 &nbsp; |</a>
                            <a href="#tomorrow00" class="text-dark tomorrow00">&nbsp; Tomorrow 00:00 &nbsp; |</a>
                            <a href="#tomorrow11" class="text-dark tomorrow11">&nbsp; Tomorrow 11:00 &nbsp; |</a>
                            <a href="#tomorrow15" class="text-dark tomorrow15">&nbsp; Tomorrow 15:00 &nbsp;</a>
                        </figure> 
                    <?php else: ?>
                    <br><br><h2>Sorry there is not product on sale!<h2>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="ps-layout--shop">
    <div class="ps-product-list ps-clothings">
        <div class="ps-container">        
            <div class="ps-shopping-product">
                <div class="row" id="product-data">
                    <?php if(!empty($flash)): ?>
                    <?php $__currentLoopData = $flash; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $starting_price = App\Models\ProductSize::where('product_id', $product_list->product_id)->first();
                    $total_price = $product_list->selling_price;
                    $product_image = App\Models\ProductImages::where('product_id', $product_list->product_id)->where('color_id', $product_list->color_id)->first();
                    $image = App\Models\Image::where('imageable_id', $product_image->id)->first();
                    ?>
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-6">
                        <div class="ps-product">
                            <div class="ps-product__thumbnail"><a href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><img src="<?php echo e(product_img($image->image)); ?>" alt=""></a>
                                <ul class="ps-product__actions">
                                    <li><a data-placement="top" class="btn-quick-view" value="<?php echo e($product_list->id); ?>" title="Quick View" data-toggle="modal" data-target="#product-quickview"><i class="icon-eye"></i></a></li>
                                    <li><a data-toggle="tooltip" data-placement="bottom" title="Add to Whishlist"><i class="icon-heart"></i></a></li>
                                </ul>
                            </div>
                            <div class="ps-product__container"><a class="ps-product__vendor" href="#"><?php echo e($product_list->product->productCategory->name); ?></a>
                                <div class="ps-product__content"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <div class="ps-product__rating">
                                        <select class="ps-rating" data-read-only="true">
                                            <option value="1">1</option>
                                            <option value="1">2</option>
                                            <option value="1">3</option>
                                            <option value="1">4</option>
                                            <option value="2">5</option>
                                        </select>
                                    </div>
                                    <p class="ps-product__price">NPR <?php echo e(number_format($starting_price['selling_price'])); ?></p>
                                </div>
                                <div class="ps-product__content hover"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <p class="ps-product__price">NPR <?php echo e(number_format($starting_price['selling_price'])); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="row" <?php if(date('H') > 11): ?> hidden <?php endif; ?> id="today11">
                    <?php if(!empty($eleven)): ?>
                    <?php $__currentLoopData = $eleven; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $starting_price = App\Models\ProductSize::where('product_id', $product_list->product_id)->first();
                    $total_price = $product_list->selling_price;
                    $product_image = App\Models\ProductImages::where('product_id', $product_list->product_id)->where('color_id', $product_list->color_id)->first();
                    $image = App\Models\Image::where('imageable_id', $product_image->id)->first();
                    ?>
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-6">
                        <div class="ps-product">
                            <div class="ps-product__thumbnail"><a href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><img src="<?php echo e(product_img($image->image)); ?>" alt=""></a>
                                <ul class="ps-product__actions">
                                    <li><a data-placement="top" class="btn-quick-view" value="<?php echo e($product_list->id); ?>" title="Quick View" data-toggle="modal" data-target="#product-quickview"><i class="icon-eye"></i></a></li>
                                    <li><a data-toggle="tooltip" data-placement="bottom" title="Add to Whishlist"><i class="icon-heart"></i></a></li>
                                </ul>
                            </div>
                            <div class="ps-product__container"><a class="ps-product__vendor" href="#"><?php echo e($product_list->product->productCategory->name); ?></a>
                                <div class="ps-product__content"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <div class="ps-product__rating">
                                        <select class="ps-rating" data-read-only="true">
                                            <option value="1">1</option>
                                            <option value="1">2</option>
                                            <option value="1">3</option>
                                            <option value="1">4</option>
                                            <option value="2">5</option>
                                        </select>
                                    </div>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                                <div class="ps-product__content hover"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="row" <?php if(date('H') > 15): ?> hidden <?php endif; ?> id="today15">
                    <?php if(!empty($three)): ?>
                    <?php $__currentLoopData = $three; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $starting_price = App\Models\ProductSize::where('product_id', $product_list->product_id)->first();
                    $total_price = $product_list->selling_price;
                    $product_image = App\Models\ProductImages::where('product_id', $product_list->product_id)->where('color_id', $product_list->color_id)->first();
                    $image = App\Models\Image::where('imageable_id', $product_image->id)->first();
                    ?>
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-6">
                        <div class="ps-product">
                            <div class="ps-product__thumbnail"><a href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><img src="<?php echo e(product_img($image->image)); ?>" alt=""></a>
                                <ul class="ps-product__actions">
                                    <li><a data-placement="top" class="btn-quick-view" value="<?php echo e($product_list->id); ?>" title="Quick View" data-toggle="modal" data-target="#product-quickview"><i class="icon-eye"></i></a></li>
                                    <li><a data-toggle="tooltip" data-placement="bottom" title="Add to Whishlist"><i class="icon-heart"></i></a></li>
                                </ul>
                            </div>
                            <div class="ps-product__container"><a class="ps-product__vendor" href="#"><?php echo e($product_list->product->productCategory->name); ?></a>
                                <div class="ps-product__content"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <div class="ps-product__rating">
                                        <select class="ps-rating" data-read-only="true">
                                            <option value="1">1</option>
                                            <option value="1">2</option>
                                            <option value="1">3</option>
                                            <option value="1">4</option>
                                            <option value="2">5</option>
                                        </select>
                                    </div>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                                <div class="ps-product__content hover"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="row" id="tomorrow00">
                    <?php if(!empty($tom0)): ?>
                    <?php $__currentLoopData = $tom0; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $starting_price = App\Models\ProductSize::where('product_id', $product_list->product_id)->first();
                    $total_price = $product_list->selling_price;
                    $product_image = App\Models\ProductImages::where('product_id', $product_list->product_id)->where('color_id', $product_list->color_id)->first();
                    $image = App\Models\Image::where('imageable_id', $product_image->id)->first();
                    ?>
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-6">
                        <div class="ps-product">
                            <div class="ps-product__thumbnail"><a href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><img src="<?php echo e(product_img($image->image)); ?>" alt=""></a>
                                <ul class="ps-product__actions">
                                    <li><a data-placement="top" class="btn-quick-view" value="<?php echo e($product_list->id); ?>" title="Quick View" data-toggle="modal" data-target="#product-quickview"><i class="icon-eye"></i></a></li>
                                    <li><a data-toggle="tooltip" data-placement="bottom" title="Add to Whishlist"><i class="icon-heart"></i></a></li>
                                </ul>
                            </div>
                            <div class="ps-product__container"><a class="ps-product__vendor" href="#"><?php echo e($product_list->product->productCategory->name); ?></a>
                                <div class="ps-product__content"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <div class="ps-product__rating">
                                        <select class="ps-rating" data-read-only="true">
                                            <option value="1">1</option>
                                            <option value="1">2</option>
                                            <option value="1">3</option>
                                            <option value="1">4</option>
                                            <option value="2">5</option>
                                        </select>
                                    </div>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                                <div class="ps-product__content hover"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="row" id="tomorrow11">
                    <?php if(!empty($tom1)): ?>
                    <?php $__currentLoopData = $tom1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $starting_price = App\Models\ProductSize::where('product_id', $product_list->product_id)->first();
                    $total_price = $product_list->selling_price;
                    $product_image = App\Models\ProductImages::where('product_id', $product_list->product_id)->where('color_id', $product_list->color_id)->first();
                    $image = App\Models\Image::where('imageable_id', $product_image->id)->first();
                    ?>
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-6">
                        <div class="ps-product">
                            <div class="ps-product__thumbnail"><a href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><img src="<?php echo e(product_img($image->image)); ?>" alt=""></a>
                                <ul class="ps-product__actions">
                                    <li><a data-placement="top" class="btn-quick-view" value="<?php echo e($product_list->id); ?>" title="Quick View" data-toggle="modal" data-target="#product-quickview"><i class="icon-eye"></i></a></li>
                                    <li><a data-toggle="tooltip" data-placement="bottom" title="Add to Whishlist"><i class="icon-heart"></i></a></li>
                                </ul>
                            </div>
                            <div class="ps-product__container"><a class="ps-product__vendor" href="#"><?php echo e($product_list->product->productCategory->name); ?></a>
                                <div class="ps-product__content"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <div class="ps-product__rating">
                                        <select class="ps-rating" data-read-only="true">
                                            <option value="1">1</option>
                                            <option value="1">2</option>
                                            <option value="1">3</option>
                                            <option value="1">4</option>
                                            <option value="2">5</option>
                                        </select>
                                    </div>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                                <div class="ps-product__content hover"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="row" id="tomorrow15">
                    <?php if(!empty($tom1)): ?>
                    <?php $__currentLoopData = $tom1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $starting_price = App\Models\ProductSize::where('product_id', $product_list->product_id)->first();
                    $total_price = $product_list->selling_price;
                    $product_image = App\Models\ProductImages::where('product_id', $product_list->product_id)->where('color_id', $product_list->color_id)->first();
                    $image = App\Models\Image::where('imageable_id', $product_image->id)->first();
                    ?>
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-6">
                        <div class="ps-product">
                            <div class="ps-product__thumbnail"><a href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><img src="<?php echo e(product_img($image->image)); ?>" alt=""></a>
                                <ul class="ps-product__actions">
                                    <li><a data-placement="top" class="btn-quick-view" value="<?php echo e($product_list->id); ?>" title="Quick View" data-toggle="modal" data-target="#product-quickview"><i class="icon-eye"></i></a></li>
                                    <li><a data-toggle="tooltip" data-placement="bottom" title="Add to Whishlist"><i class="icon-heart"></i></a></li>
                                </ul>
                            </div>
                            <div class="ps-product__container"><a class="ps-product__vendor" href="#"><?php echo e($product_list->product->productCategory->name); ?></a>
                                <div class="ps-product__content"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <div class="ps-product__rating">
                                        <select class="ps-rating" data-read-only="true">
                                            <option value="1">1</option>
                                            <option value="1">2</option>
                                            <option value="1">3</option>
                                            <option value="1">4</option>
                                            <option value="2">5</option>
                                        </select>
                                    </div>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                                <div class="ps-product__content hover"><a class="ps-product__title" href="<?php echo e(route('single-product', $product_list->product->slug)); ?>"><?php echo e($product_list->product->name); ?></a>
                                    <p class="ps-product__price"><?php if(date('H') < 15): ?> ??? <?php else: ?> NPR <?php echo e(number_format($starting_price['selling_price'])); ?> <?php endif; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/frontend/pages/flash.blade.php ENDPATH**/ ?>