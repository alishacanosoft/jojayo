<aside class="widget widget--blog widget--search">
  <form class="ps-form--widget-search" action="<?php echo e(route('searchBlog')); ?>" method="get">
    <input class="form-control" type="text" name="s" placeholder="Search...">
    <button type="submit"><i class="icon-magnifier"></i></button>
  </form>
</aside>
<aside class="widget widget--blog widget--categories">
  <h3 class="widget__title">Categories</h3>
  <div class="widget__content">
  <?php if(!empty($bcategories)): ?>
    <ul>
    <?php $__currentLoopData = $bcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url('/blogs/categories/'.$bcategory->slug)); ?>"><?php echo e(ucwords($bcategory->name)); ?></a></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php endif; ?>
  </div>
</aside>
<aside class="widget widget--blog widget--categories">
  <h3 class="widget__title">Recent Posts</h3>
  <div class="widget__content">
  <?php if(!empty($latestPosts)): ?>
  <ul>
    <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(url('/blogs/'.$latest->slug)); ?>"><?php echo e(ucwords($latest->title)); ?></a></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  <?php endif; ?>
  </div>
</aside><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/frontend/pages/blog-sidebar.blade.php ENDPATH**/ ?>