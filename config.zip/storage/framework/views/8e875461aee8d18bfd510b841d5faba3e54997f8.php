<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="author" content="JoJayo">

    <meta name="description" content="JOJAYO" />
    <meta name="keywords" content="jojayo, shopping, e-commerce" />
    <link rel="canonical" href="https://jojayo.com/" />

    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>" />
    <link rel="apple-touch-icon" href="<?php echo e(asset('images/apple-touch-icon.png')); ?>" />
    <link rel="android-chrome-192x192" href="<?php echo e(asset('images/android-chrome-192x192.png')); ?>" />
    <link rel="android-chrome-512x512" href="<?php echo e(asset('images/android-chrome-512x512.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('images/site.webmanifest')); ?>">


    <meta property="og:type" content="ecommerce-website" />
    <meta property="og:title" content="JOJAYO" />
    <meta property="og:description" content="JOJAYO" />
    <meta property="og:url" content="https://jojayo.com/" />
    <meta property="og:site_name" content="JOJAYO" />
    <meta property="og:image" content="<?php echo e(asset('images/jojayo_logo.png')); ?>" />

    <title>JoJayo Shopping</title>
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,500,600,700&amp;amp;subset=latin-ext" rel="stylesheet">
   
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/plugins/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/fonts/Linearicons/Linearicons/Font/demo-files/demo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/plugins/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/plugins/owl-carousel/assets/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/plugins/owl-carousel/assets/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/plugins/slick/slick/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/plugins/nouislider/nouislider.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/plugins/lightGallery-master/dist/css/lightgallery.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/plugins/jquery-bar-rating/dist/themes/fontawesome-stars.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/plugins/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend1/css/style.css')); ?>">
    <style>
        /* width */
        .productList::-webkit-scrollbar {
        width: 10px;
        }

        /* Track */
        .productList::-webkit-scrollbar-track {
        background: #000!important
        }

        /* Handle */
        .productList::-webkit-scrollbar-thumb {
        background: #888;
        }

        /* Handle on hover */
        .productList::-webkit-scrollbar-thumb:hover {
        background: #555;
        }
        .productList{
            position: absolute!important;
            top: 100%;
            transform: scaleX(1);
            padding: 0 20px;
            background: #fff!important;
            z-index: 9999!important;
            border: 1px solid #ccc;
            border-top: none;
            overflow-y: auto;
            display: none;
            width: 100%;
        }
        .productList li{
            cursor: pointer;
            padding: 10px;
            transition: 0.5s;
          }

        .productList li:hover{
            background: #000000;
            color: #fff;
        }
        
        .productListMob li{
            padding: 5px 15px;
            border-bottom: 1px solid #000;
        }
        @media (min-width: 576px){
            #loginModal .modal-dialog {
                max-width: 394;
            }
        }
        #loginModal .ps-form--account{
            box-shadow:none;
        }
        .top-bar{
            background: #f1f1f1;
        }
        .menu.text-right > li > a{
            padding: 5px 10px;
            font-size:13px;
            color:#000;
        }
      .font-13{
          font-size: 13px;
      } 
      .font-weight-normal{
          font-weight: normal;
      }
    </style>
    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body>

<?php if(Route::is('single-product') ): ?>
<header class="header header--1" data-sticky="false" id="jojayo-header">
      <div class="header__top">
        <div class="ps-container">
          <div class="header__left">
            <div class="menu--product-categories">
            <ul id="nav">  
                <li class="yahoo">      
                <div class="menu__toggle"><i class="icon-menu"></i><span> Shop By Categories</span></div>
                    <ul style="z-index:1000;min-width:260px;margin-top:10px">
                        <?php if(!empty($primary_categories)): ?>
                        <?php $__currentLoopData = $primary_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($prime->secondaryCategories->count() > 0): ?>
                            <li><a href="#"><i class="<?php echo e($prime->icon); ?>"></i> <?php echo e($prime->name); ?> »</a>            
                                <ul>
                                    <?php $__currentLoopData = $prime->secondaryCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($secondary->FinalCategory->count() > 0): ?>
                                        <?php
                                        $secondary->name = str_replace("Women's", "", $secondary->name);
                                        $secondary->name = str_replace("Men's", "", $secondary->name);
                                        ?>
                                        <li><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e($secondary->name); ?> »</a>
                                        <ul>
                                            <?php $__currentLoopData = $secondary->FinalCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $final_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $final_cat->name = str_replace("Women's", "", $final_cat->name);
                                            $final_cat->name = str_replace("Men's", "", $final_cat->name);
                                            ?>
                                            <li><a href="<?php echo e(route('categories.sec', [$secondary->slug,$final_cat->slug])); ?>"><?php echo e($final_cat->name); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        </li>
                                        <?php else: ?>
                                        <li><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e($secondary->name); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                        
                                </ul>
                            </li>
                            <?php else: ?>
                            <li><a href="#"><i class="<?php echo e($prime->icon); ?>"></i> <?php echo e($prime->name); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </li>
              </ul> 
            </div>
            <a class="ps-logo" href="<?php echo e(url('/')); ?>"><img src="<?php echo e($sensitive_data->logo); ?>" alt="jojayo-logo"></a>
          </div>
          <div class="header__center">
            <form class="ps-form--quick-search" action="<?php echo e(route('searchProduct')); ?>" method="GET">
            <!-- <?php echo csrf_field(); ?> -->
              <div class="form-group--icon"><i class="icon-chevron-down"></i>
               
                <select class="form-control resizeselect" id="searchCategory" style="text-indent: 0" name="category">
                                <option value="all" <?php echo e(($selected_category = 'all') ? 'selected':''); ?>>All</option>
                                <?php $__currentLoopData = $primary_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($prime->secondaryCategories->count() > 0): ?>
                                        <?php $__currentLoopData = $prime->secondaryCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($secondary->FinalCategory->count() > 0): ?>

                                                <?php
                                                    $secondary->name = str_replace("Women's", "", $secondary->name);
                                                    $secondary->name = str_replace("Men's", "", $secondary->name);
                                                ?>

                                                <option disabled class="level-0" value="<?php echo e($secondary->slug); ?>"><?php echo e(trim($secondary->name)); ?></option>

                                                <?php $__currentLoopData = $secondary->FinalCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $final_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $final_cat->name = str_replace("Women's", "", $final_cat->name);
                                                        $final_cat->name = str_replace("Men's", "", $final_cat->name);
                                                    ?>
                                                    <option class="level-1" value="<?php echo e($final_cat->slug); ?>" <?php echo e((@$selected_category == $final_cat->slug) ? 'selected':''); ?>>&nbsp;&nbsp;&nbsp;<?php echo e(trim($final_cat->name)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

            <div class="search-top">
             <input class="form-control" required name="q" id="productSearch"   type="text" placeholder="I'm shopping for...">
                <div id="productList" class="productList">
                </div>         
            </div>
            <button >Search</button>
            </form>
          </div>
          <div class="header__right">
            <div class="header__actions">
            
            <a class="header__extra" href="#"><i class="icon-heart"></i><span><i class="wish-count"><?php echo e(Cart::instance('wishlist')->content()->count()); ?></i></span></a>
              <div class="ps-cart--mini"><a class="header__extra" href="#"><i class="icon-bag2"></i><span><i class="cart-count"><?php echo e(Cart::instance('cart')->content()->count()); ?></i></span></a>
                    <div class="ps-cart__content">
                        <div class="ps-cart__items">
                        <?php if(!empty(Cart::content())): ?>
                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ps-product--cart-mobile">
                                <div class="ps-product__thumbnail"><a href="#"><img src="<?php echo e(url('/uploads/products/'.$row->options->image)); ?>" alt=""></a></div>
                                <div class="ps-product__content"><a class="ps-product__remove" value="<?php echo e($row->rowId); ?>"><i class="icon-cross"></i></a><a href="<?php echo e(route('single-product', $row->options->slug)); ?>"><?php echo e($row->name); ?></a>
                                    <!-- <p><strong>Sold by:</strong> YOUNG SHOP</p> --> <br>
                                    <small><?php echo e($row->qty); ?> x NPR <?php echo e(number_format($row->price)); ?></small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </div>
                        <div class="ps-cart__footer">
                            <h3>Sub Total:<strong class="cart-total-price">NPR <?php echo e(Cart::total()); ?></strong></h3>
                            <figure>
                                <a class="ps-btn ps-btn--fullwidth" href="<?php echo e(route('cart.index')); ?>" style="margin-right:2px">View Cart</a>
                                <?php if(\Auth::user() == null || \Auth::user()->roles !== 'customers'): ?>
                                <a class="ps-btn ps-btn--fullwidth" href="#" data-toggle="modal" data-target="#loginModal" style="margin-left:2px">Checkout</a>
                                <?php else: ?>
                                <a class="ps-btn ps-btn--fullwidth" href="<?php echo e(route('review')); ?>" style="margin-left:2px">Checkout</a>
                                <?php endif; ?>
                                </figure>
                        </div>
                    </div>
              </div>
              <div class="ps-block--user-header">
                <div class="ps-block__left"><i class="icon-user"></i></div>
                <div class="ps-block__right">
                          

                <?php if(!empty(Auth::user()) && Auth::user()->roles == 'customers'): ?>
                <div class="ps-block--user-header">
                    <div class="dropdown">
                        <button class="btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="ps-block__left text-dark font-13 font-weight-normal">
                            <i class="icon-user text-dark"></i>&nbsp;My Account
                            &nbsp;<i class="fa fa-angle-down text-dark"></i></div>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="<?php echo e(url('/dashboard')); ?>">My Dashboard</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Log Out</a>
                        </div>
                    </div>
                </div> 
                <?php else: ?>
                <a href="<?php echo e(route('signinform')); ?>">Login & Register</a>
                    
                <?php endif; ?>
                
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <nav class="navigation">
        <div class="ps-container">
          <div class="navigation__left">
            <div class="menu--product-categories">            
              <ul id="nav">  
                <li class="yahoo">      
                <div class="menu__toggle"><i class="icon-menu"></i><span> Shop By Categories</span></div>
                    <ul style="z-index:1000;min-width:260px;margin-top:10px">
                        <?php if(!empty($primary_categories)): ?>
                        <?php $__currentLoopData = $primary_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($prime->secondaryCategories->count() > 0): ?>
                            <li><a href="#"><i class="<?php echo e($prime->icon); ?>"></i> <?php echo e($prime->name); ?> »</a>            
                                <ul>
                                    <?php $__currentLoopData = $prime->secondaryCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($secondary->FinalCategory->count() > 0): ?>
                                        <?php
                                        $secondary->name = str_replace("Women's", "", $secondary->name);
                                        $secondary->name = str_replace("Men's", "", $secondary->name);
                                        ?>
                                        <li><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e(ucwords($secondary->name)); ?> »</a>
                                        <ul>
                                            <?php $__currentLoopData = $secondary->FinalCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $final_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $final_cat->name = str_replace("Women's", "", $final_cat->name);
                                            $final_cat->name = str_replace("Men's", "", $final_cat->name);
                                            ?>
                                            <li><a href="<?php echo e(route('categories.sec', [$secondary->slug,$final_cat->slug])); ?>"><?php echo e(ucwords($final_cat->name)); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        </li>
                                        <?php else: ?>
                                        <li><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e(ucwords($secondary->name)); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                        
                                </ul>
                            </li>
                            <?php else: ?>
                            <li><a href="#"><i class="<?php echo e($prime->icon); ?>"></i> <?php echo e($prime->name); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </li>
              </ul>  
            </div>
          </div>
          <div class="navigation__right">
                        <ul class="menu">
                            <li><a href="<?php echo e(url('/')); ?>">Home</a>
                            </li>
                            <li><a href="<?php echo e(url('/shop')); ?>">Shop</a></li>
                            <li><a href="<?php echo e(url('/about-us')); ?>">About</a></li>
                            <li><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a></li> 
                        </ul>
            <ul class="navigation__extra">
              <li><a href="<?php echo e(url('/vendor')); ?>">Sell on JoJayo</a></li>
             
            </ul>
          </div>
        </div>
      </nav>
</header>
<?php else: ?>
<header class="header header--1" data-sticky="true" id="jojayo-header">
      <div class="header__top">
        <div class="ps-container">
          <div class="header__left">
            <div class="menu--product-categories">
            <ul id="nav">  
                <li class="yahoo">      
                <div class="menu__toggle"><i class="icon-menu"></i><span> Shop By Categories</span></div>
                    <ul style="z-index:1000;min-width:260px;margin-top:10px">
                        <?php if(!empty($primary_categories)): ?>
                        <?php $__currentLoopData = $primary_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($prime->secondaryCategories->count() > 0): ?>
                            <li><a href="#"><i class="<?php echo e($prime->icon); ?>"></i> <?php echo e($prime->name); ?> »</a>            
                                <ul>
                                    <?php $__currentLoopData = $prime->secondaryCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($secondary->FinalCategory->count() > 0): ?>
                                        <?php
                                        $secondary->name = str_replace("Women's", "", $secondary->name);
                                        $secondary->name = str_replace("Men's", "", $secondary->name);
                                        ?>
                                        <li><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e($secondary->name); ?> »</a>
                                        <ul>
                                            <?php $__currentLoopData = $secondary->FinalCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $final_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $final_cat->name = str_replace("Women's", "", $final_cat->name);
                                            $final_cat->name = str_replace("Men's", "", $final_cat->name);
                                            ?>
                                            <li><a href="<?php echo e(route('categories.sec', [$secondary->slug,$final_cat->slug])); ?>"><?php echo e($final_cat->name); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        </li>
                                        <?php else: ?>
                                        <li><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e($secondary->name); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                        
                                </ul>
                            </li>
                            <?php else: ?>
                            <li><a href="#"><i class="<?php echo e($prime->icon); ?>"></i> <?php echo e($prime->name); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </li>
              </ul> 
            </div>
            <a class="ps-logo" href="<?php echo e(url('/')); ?>"><img src="<?php echo e($sensitive_data->logo); ?>" alt="jojayo-logo"></a>
          </div>
          <div class="header__center">
            <form class="ps-form--quick-search" action="<?php echo e(route('searchProduct')); ?>" method="GET">
            <!-- <?php echo csrf_field(); ?> -->
              <div class="form-group--icon"><i class="icon-chevron-down"></i>
               
                <select class="form-control resizeselect" id="searchCategory" style="text-indent: 0" name="category">
                                <option value="all" <?php echo e(($selected_category = 'all') ? 'selected':''); ?>>All</option>
                                <?php $__currentLoopData = $primary_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($prime->secondaryCategories->count() > 0): ?>
                                        <?php $__currentLoopData = $prime->secondaryCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($secondary->FinalCategory->count() > 0): ?>

                                                <?php
                                                    $secondary->name = str_replace("Women's", "", $secondary->name);
                                                    $secondary->name = str_replace("Men's", "", $secondary->name);
                                                ?>

                                                <option disabled class="level-0" value="<?php echo e($secondary->slug); ?>"><?php echo e(trim($secondary->name)); ?></option>

                                                <?php $__currentLoopData = $secondary->FinalCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $final_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $final_cat->name = str_replace("Women's", "", $final_cat->name);
                                                        $final_cat->name = str_replace("Men's", "", $final_cat->name);
                                                    ?>
                                                    <option class="level-1" value="<?php echo e($final_cat->slug); ?>" <?php echo e((@$selected_category == $final_cat->slug) ? 'selected':''); ?>>&nbsp;&nbsp;&nbsp;<?php echo e(trim($final_cat->name)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            <div class="search-top">
             <input class="form-control" required name="q" id="productSearch"   type="text" placeholder="I'm shopping for...">
                        <div id="productList" class="productList">
                        </div>
            </div>
                <button>Search</button>
            </form>
          </div>
          <div class="header__right">
            <div class="header__actions">
            
            <a class="header__extra" href="#"><i class="icon-heart"></i><span><i>0</i></span></a>
              <div class="ps-cart--mini"><a class="header__extra" href="#"><i class="icon-bag2"></i><span><i class="cart-count"><?php echo e(Cart::content()->count()); ?></i></span></a>
                    <div class="ps-cart__content">
                        <div class="ps-cart__items">
                        <?php if(!empty(Cart::content())): ?>
                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ps-product--cart-mobile">
                                <div class="ps-product__thumbnail"><a href="#"><img src="<?php echo e(url('/uploads/products/'.$row->options->image)); ?>" alt=""></a></div>
                                <div class="ps-product__content"><a class="ps-product__remove" value="<?php echo e($row->rowId); ?>"><i class="icon-cross"></i></a><a href="<?php echo e(route('single-product', $row->options->slug)); ?>"><?php echo e($row->name); ?></a>
                                    <!-- <p><strong>Sold by:</strong> YOUNG SHOP</p> --> <br>
                                    <small><?php echo e($row->qty); ?> x NPR <?php echo e(number_format($row->price)); ?></small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </div>
                        <div class="ps-cart__footer">
                            <h3>Sub Total:<strong class="cart-total-price">NPR <?php echo e(Cart::total()); ?></strong></h3>
                            <figure>
                                <a class="ps-btn ps-btn--fullwidth" href="<?php echo e(route('cart.index')); ?>" style="margin-right:2px">View Cart</a>
                                <?php if(\Auth::user() == null || \Auth::user()->roles !== 'customers'): ?>
                                <a class="ps-btn ps-btn--fullwidth" href="#" data-toggle="modal" data-target="#loginModal" style="margin-left:2px">Checkout</a>
                                <?php else: ?>
                                <a class="ps-btn ps-btn--fullwidth" href="<?php echo e(route('review')); ?>" style="margin-left:2px">Checkout</a>
                                <?php endif; ?>
                                </figure>
                        </div>
                    </div>
              </div>
              <div class="ps-block--user-header">
               
                <div class="ps-block__right">
                          
                <?php if(!empty(Auth::user()) && Auth::user()->roles == 'customers'): ?>
                <div class="ps-block--user-header">
                    <div class="dropdown">
                        <button class="btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="ps-block__left text-dark font-13 font-weight-normal">
                            <i class="icon-user text-dark"></i>&nbsp;My Account
                            &nbsp;<i class="fa fa-angle-down text-dark"></i></div>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="<?php echo e(url('/dashboard')); ?>">My Dashboard</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Log Out</a>
                        </div>
                    </div>
                </div> 
                <?php else: ?>
                <div class="ps-block__left"><i class="icon-user"></i> <a href="<?php echo e(route('signinform')); ?>">Login & Register</a></div> 
                <?php endif; ?>
                
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <nav class="navigation">
        <div class="ps-container">
          <div class="navigation__left">
            <div class="menu--product-categories">            
              <ul id="nav">  
                <li class="yahoo">      
                <div class="menu__toggle"><i class="icon-menu"></i><span> Shop By Categories</span></div>
                    <ul style="z-index:1000;min-width:260px;margin-top: 10px;">
                        <?php if(!empty($primary_categories)): ?>
                        <?php $__currentLoopData = $primary_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($prime->secondaryCategories->count() > 0): ?>
                            <li><a href="#"><i class="<?php echo e($prime->icon); ?>"></i> <?php echo e($prime->name); ?> »</a>            
                                <ul>
                                    <?php $__currentLoopData = $prime->secondaryCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($secondary->FinalCategory->count() > 0): ?>
                                        <?php
                                        $secondary->name = str_replace("Women's", "", $secondary->name);
                                        $secondary->name = str_replace("Men's", "", $secondary->name);
                                        ?>
                                        <li><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e(ucwords($secondary->name)); ?> »</a>
                                        <ul>
                                            <?php $__currentLoopData = $secondary->FinalCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $final_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $final_cat->name = str_replace("Women's", "", $final_cat->name);
                                            $final_cat->name = str_replace("Men's", "", $final_cat->name);
                                            ?>
                                            <li><a href="<?php echo e(route('categories.sec', [$secondary->slug,$final_cat->slug])); ?>"><?php echo e(ucwords($final_cat->name)); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        </li>
                                        <?php else: ?>
                                        <li><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e(ucwords($secondary->name)); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                        
                                </ul>
                            </li>
                            <?php else: ?>
                            <li><a href="#"><i class="<?php echo e($prime->icon); ?>"></i> <?php echo e($prime->name); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </li>
              </ul>  
            </div>
          </div>
          <div class="navigation__right">
                        <ul class="menu">
                            <li><a href="<?php echo e(url('/')); ?>">Home</a>
                            </li>
                            <li><a href="<?php echo e(url('/shop')); ?>">Shop</a></li>
                            <li><a href="<?php echo e(url('/about-us')); ?>">About</a></li>
                            <li><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a></li> 
                        </ul>
            <ul class="navigation__extra">
              <li><a href="<?php echo e(url('/vendor')); ?>">Sell on JoJayo</a></li>
             
            </ul>
          </div>
        </div>
      </nav>
</header>

<header class="header header--mobile" data-sticky="true">
    <div class="header__top">
      <div class="header__left">
        <p>Welcome to JoJayo Online Shopping Store !</p>
      </div>
      <div class="header__right">
        <ul class="navigation__extra">
          <li><a href="<?php echo e(url('/vendor')); ?>">Sell on JoJayo</a></li>
          
        </ul>
      </div>
    </div>
    <div class="navigation--mobile">
          <div class="navigation__left"><a class="ps-logo" href="<?php echo e(url('/')); ?>"><img src="<?php echo e($sensitive_data->logo); ?>" alt=""></a></div>
          <div class="navigation__right">
              <div class="header__actions">
                  <div class="ps-cart--mini"><a class="header__extra" href="#"><i class="icon-bag2"></i><span><i>0</i></span></a>
                      <div class="ps-cart__content">
                          <div class="ps-cart__items">
                          <?php if(!empty(Cart::content())): ?>
                              <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="ps-product--cart-mobile">
                                  <div class="ps-product__thumbnail"><a href="<?php echo e(route('single-product', $row->options->slug)); ?>"><img src="<?php echo e(url('/uploads/products/'.$row->options->image)); ?>" alt=""></a></div>
                                  <div class="ps-product__content"><a class="ps-product__remove" value="<?php echo e($row->rowId); ?>" href="#"><i class="icon-cross"></i></a><a href="<?php echo e(route('single-product', $row->options->slug)); ?>"><?php echo e($row->name); ?></a>
                                      <small><?php echo e($row->qty); ?> x NPR <?php echo e(number_format($row->price)); ?></small>
                                  </div>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                          </div>
                          <div class="ps-cart__footer">
                              <h3>Sub Total:<strong><?php echo e(Cart::total()); ?></strong></h3>
                              <figure><a class="ps-btn" href="<?php echo e(route('cart.index')); ?>">View Cart</a><a class="ps-btn" href="<?php echo e(route('review')); ?>">Checkout</a></figure>
                          </div>
                      </div>
                  </div>
                  <div class="ps-block--user-header">
                      <div class="ps-block__left"><a href="<?php echo e(route('signinform')); ?>"><i class="icon-user"></i></a></div>
                      <div class="ps-block__right"><a href="<?php echo e(route('signinform')); ?>">Login</a></div>
                  </div>
              </div>
          </div>
      </div>
    <!-- <div class="ps-search--mobile">
      <form class="ps-form--search-mobile" action="" method="get">
        <div class="form-group--nest">
          <input class="form-control" type="text" placeholder="Search something...">
          <button><i class="icon-magnifier"></i></button>
        </div>
      </form>
    </div> -->
  </header>

    <div class="ps-panel--sidebar" id="cart-mobile">
      <div class="ps-panel__header">
        <h3>Shopping Cart</h3>
      </div>
      <div class="navigation__content">
            <div class="ps-cart--mobile">
                <div class="ps-cart__content">
                <?php if(!empty(Cart::content())): ?>
                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="ps-product--cart-mobile">
                        <div class="ps-product__thumbnail"><a href="<?php echo e(route('single-product', $row->options->slug)); ?>"><img src="<?php echo e(url('/uploads/products/'.$row->options->image)); ?>" alt=""></a></div>
                        <div class="ps-product__content"><a class="ps-product__remove" value="<?php echo e($row->rowId); ?>" href="#"><i class="icon-cross"></i></a><a href="<?php echo e(route('single-product', $row->options->slug)); ?>"><?php echo e($row->name); ?></a>
                            <small><?php echo e($row->qty); ?> x NPR <?php echo e(number_format($row->price)); ?></small>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </div>
                <div class="ps-cart__footer">
                    <h3>Sub Total:<strong>NPR <?php echo e(Cart::total()); ?></strong></h3>
                    <figure><a class="ps-btn" href="<?php echo e(route('cart.index')); ?>">View Cart</a><a class="ps-btn" href="<?php echo e(route('review')); ?>">Checkout</a></figure>
                </div>
            </div>
        </div>
    </div>
    <div class="ps-panel--sidebar" id="navigation-mobile">
      <div class="ps-panel__header">
        <h3>Categories</h3>
      </div>
      <div class="ps-panel__content">
           <ul class="menu--mobile">
                <?php if(!empty($primary_categories)): ?>
                    <?php $__currentLoopData = $primary_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($prime->secondaryCategories->count() > 0): ?>
                        <li class="current-menu-item menu-item-has-children has-mega-menu">
                            <a href="#"><?php echo e($prime->name); ?></a><span class="sub-toggle"></span>
                            <div class="mega-menu">
                                <?php $__currentLoopData = $prime->secondaryCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($secondary->FinalCategory->count() > 0): ?>
                                        <?php
                                            $secondary->name = str_replace("Women's", "", $secondary->name);
                                            $secondary->name = str_replace("Men's", "", $secondary->name);
                                        ?>
                                        <div class="mega-menu__column">
                                            <h4><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e(ucwords($secondary->name)); ?></a><span class="sub-toggle"></span></h4>
                                            <ul class="mega-menu__list">
                                                <?php $__currentLoopData = $secondary->FinalCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $final_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $final_cat->name = str_replace("Women's", "", $final_cat->name);
                                                        $final_cat->name = str_replace("Men's", "", $final_cat->name);
                                                    ?>
                                                    <li class="current-menu-item ">
                                                        <a href="<?php echo e(route('categories.sec', [$secondary->slug,$final_cat->slug])); ?>"><?php echo e(ucwords($final_cat->name)); ?></a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php else: ?>
                                        <h4><a href="<?php echo e(route('categories', $secondary->slug)); ?>"><?php echo e(ucwords($secondary->name)); ?></a></h4>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                        <?php else: ?>
                        <li class="current-menu-item "><a href="#"><?php echo e($prime->name); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </ul>
              </div>
    </div>
    <div class="navigation--list">
      <div class="navigation__content"><a class="navigation__item ps-toggle--sidebar" href="#menu-mobile"><i class="icon-menu"></i><span> Menu</span></a><a class="navigation__item ps-toggle--sidebar" href="#navigation-mobile"><i class="icon-list4"></i><span> Categories</span></a><a class="navigation__item ps-toggle--sidebar" href="#search-sidebar"><i class="icon-magnifier"></i><span> Search</span></a><a class="navigation__item ps-toggle--sidebar" href="#cart-mobile"><i class="icon-bag2"></i><span> Cart</span></a></div>
    </div>
    <div class="ps-panel--sidebar" id="search-sidebar">

        <div class="ps-panel__header">
            <form class="ps-form--search-mobile" action="<?php echo e(route('searchProduct')); ?>" method="GET" autocomplete="off">
            <!-- <?php echo csrf_field(); ?> -->
               
            <div class="form-group--nest">
                    <input type="hidden" name="category" value="all">
                    <input class="form-control" name="q" id="productSearchMob" value="<?php echo e(@$query); ?>" type="text" placeholder="Search something...">
                    <button><i class="icon-magnifier"></i></button>
                </div>

              
            </form>
        </div>
      <div class="navigation__content"></div>
    </div>
    <div class="ps-panel--sidebar" id="menu-mobile">
      <div class="ps-panel__header">
        <h3>Menu</h3>
      </div>
      <div class="ps-panel__content">
                    <ul class="menu--mobile">
                    <li class="current-menu-item "><a href="/">Home</a>
                    </li>
                    <li class="current-menu-item "><a href="<?php echo e(url('/shop')); ?>">Shop</a>
                    </li>
                    <li class="current-menu-item "><a href="<?php echo e(url('/about-us')); ?>">About</a>
                    </li>
                    <li class="current-menu-item "><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a>
                    </li>
                    
                    </ul>
      </div>
    </div>
  
<?php endif; ?>


  
<?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/frontend/partials/header.blade.php ENDPATH**/ ?>