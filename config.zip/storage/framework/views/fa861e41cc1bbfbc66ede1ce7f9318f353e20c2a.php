<?php $__env->startSection('content'); ?>
<div class="row">
            <!--<input type="text" name="daterange" value="01/01/2018 - 01/15/2018" />-->
            <?php
            $vendor_id = App\Models\Vendor::where('user_id', \Auth::user()->id)->first();
            ?>
            <div class="form-group <?php if(!Auth::user()->admin()): ?> hidden <?php endif; ?>">
                 <div class="col-md-4 col-lg-4 same-row" style="padding-top:5px">
                    <label>Supplier</label>
                    <select name="vendor_id" id="vendor_id" class="requires form-control">
                        <option selected disabled>--Select Vendor--</option>
                        <?php if(!empty($all_vendor)): ?>
                        <?php $__currentLoopData = $all_vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vendor_list->id); ?>" <?php if($vendor_list->id == @$vendor_id->id): ?> selected <?php endif; ?>><?php echo e($vendor_list->company); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                 </div>
            </div>
            
            <div class="form-group">
                 <div class="col-md-4 col-lg-4 same-row">
                    <label>Period</label>
                    <select name="date" id="date" class="requires form-control">
                        <option selected disabled>--Select Transaction Date--</option>
                    </select>
                 </div>
            </div>
            
        </div>
        <br><hr style="border-top: 1px solid #ffffff;"><br>
<div class="row">
   <div class="col-lg-12">
      <div class="row">
         <div class="col-sm-12">
            <div class="nav-tabs-custom">
               <ul class="nav nav-tabs">
                  <li class=" active"><a href="#create" data-toggle="tab">Update Transaction Detail</a></li>
               </ul>
               <div class="tab-content bg-white">
                  <div class="tab-pane  active " id="create">
                      <div class="row">                        
                        <div class="col-sm-12"> 
                            <form action="<?php echo e(route('updateTransaction')); ?>" method="POST" class="form-horizontal" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"><strong>Transaction No</strong> <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="" name="transaction_no" id="transaction_no">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"><strong>Paid Amount</strong> <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="" name="paid_amount" id="paid_amount">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"><strong>Due Amount</strong> <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="" name="due_amount" id="due_amount">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"><strong>Status</strong> <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <select name="status" class="form-control">
                                            <option value="paid" >Paid</option>
                                            <option value="paid" >Unpaid</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"><strong>Narration</strong> <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <textarea class="form-control" name="narration" rows="3"></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>
                                    <div class="col-sm-8">
                                        <button type="submit" class="btn btn-primary m-b-0 m-r-5">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                      </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/admin/pages/transaction.blade.php ENDPATH**/ ?>