<aside class="widget widget_shop">
    <h4 class="widget-title">Categories</h4>
    <ul class="ps-list--categories">
        <?php if($cat['secondary']): ?>
        <?php $__currentLoopData = $cat['cat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="current-menu-item menu-item-has-children">
            <a href="<?php echo e(route('categories', $category->slug)); ?>"><?php echo e($category->name); ?></a>
            <span class="sub-toggle">
                <i class="fa fa-angle-down"></i>
            </span>
            <ul class="sub-menu">
                <?php $__currentLoopData = $category->FinalCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $final): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="current-menu-item ">
                    <a href="<?php echo e(route('categories.sec',[$cat['primary_slug'], $final->slug])); ?>"><?php echo e($final->name); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(!$cat['secondary']): ?>
        <?php $__currentLoopData = $cat['cat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="current-menu-item menu-item-has-children">
            <a href="<?php echo e(route('categories.sec',[$cat['primary_slug'], $category->slug])); ?>"><?php echo e($category->name); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
    </ul>
</aside>
<?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/frontend/pages/filters/categories.blade.php ENDPATH**/ ?>