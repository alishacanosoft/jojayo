<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-lg-12">
      <div class="row">
         <div class="col-sm-12">
            <div class="panel panel-custom ">
                <header class="panel-heading">All Posts</header>
                <div class="panel-body">
                <table class="datatable_action display">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Status</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($allPosts)): ?> <?php $__currentLoopData = $allPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsLists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="<?php echo e($postsLists->id); ?>">
                            <td><input type="checkbox" name="delete_items" value="<?php echo e($postsLists->id); ?>"></td>
                            <td><?php echo e($postsLists->title); ?></td>
                            <td><?php echo e($postsLists->category['name']); ?></td>
                            <td><?php echo e($postsLists->status); ?></td>
                            <td><a href="<?php echo e(asset('/uploads/blogs/Thumb-'.$postsLists->image)); ?>" target="_blank">View image</a></td>
                            <td>
                                <a href="<?php echo e(route('blogs.edit', $postsLists->id)); ?>" class="btn btn-primary btn-xs" style="margin-right: 5px">
                                    <i class="fa fa-pencil-square-o"></i>
                                </a>
                                <a onclick="return confirm('Are you sure you want to delete this post?')" style="display:inline-block">
                                    <form method="POST" action="<?php echo e(route('blogs.destroy', $postsLists->id)); ?>" accept-charset="UTF-8">
                                        <input name="_method" type="hidden" value="DELETE">
                                        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                        <button class="btn btn-danger btn-xs" type="submit"><i class="fa fa-trash-o"></i></button>
                                    </form>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/admin/pages/blogs.blade.php ENDPATH**/ ?>