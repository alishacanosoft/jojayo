<div class="col-lg-12">
   <div class="panel panel-default">
      <div class="panel-body">
         <table class="table table-condensed" style="border-collapse:collapse;">
            <thead>
               <tr>
                  <th>&nbsp;</th>
                  <th>Order Id</th>
                  <th>Transaction Id</th>
                  <th>Delivery Charge</th>
                  <th>Total Transcation</th>
                  <th>Statement</th>
                  <th>Print</th>
               </tr>
            </thead>
            <tbody>
            <?php $total = 0; ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $order_data = \App\Models\Order::with(['vendor_products' => function($query) use ($id) {
                    $query->whereHas('products', function ($query) use ($id) {
                        $query->where('vendor_id', $id);
                    });
            }])->where('id',$data_detail->order_id)->get();
            ?>
            <?php $__currentLoopData = $order_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $delivery_charge = App\Models\Area::where('id',$order_detail->area_id)->first();
            if($order_detail->delivery_type == 'express'){
            $charge = $delivery_charge->express_charge;
            } else {
            $charge = $delivery_charge->delivery_charge;
            }
            $order_price = 0;
            foreach($order_detail->vendor_products as $price_data){
            $order_price = $price_data->price + $order_price;
            if(date('d', strtotime($price_data->created_at)) > 7 && date('d', strtotime($price_data->created_at)) <= 14){
                $account_statement = date('d F Y',strtotime($price_data->created_at)).' - '.date('14 F Y',strtotime($price_data->created_at));
            } elseif(date('d', strtotime($price_data->created_at)) > 14 && date('d', strtotime($price_data->created_at)) <= 21) {
                $account_statement = date('d F Y',strtotime($price_data->created_at)).' - '.date('21 F Y',strtotime($price_data->created_at));
            } elseif(date('d', strtotime($price_data->created_at)) > 21 && date('d', strtotime($price_data->created_at)) <= 28) {
                $account_statement = date('d F Y',strtotime($price_data->created_at)).' - '.date('28 F Y',strtotime($price_data->created_at));
            } elseif(date('d', strtotime($price_data->created_at)) <= 7) {
                $account_statement = date('d F Y',strtotime($price_data->created_at)).' - '.date('7 F Y',strtotime($price_data->created_at));
            }
            }
            ?>
               <tr>
                  <td data-toggle="collapse" data-target="#demo<?php echo e($order_detail->order_no); ?>" class="accordion-toggle"><button class="btn btn-default btn-xs"><span class="fa fa-plus"></span></button></td>
                  <td><form target="_blank" action="/auth/order-details"><input type="hidden" value="<?php echo e($order_detail->order_no); ?>" name="order_no"><button class="btn-transparent" type="submit"><?php echo e($order_detail->order_no); ?></button></form></td>
                  <td><form target="_blank" action="<?php echo e(route('transaction')); ?>"><input type="hidden" name="vendor_id" value="<?php echo e($id); ?>"><input type="hidden" name="transaction_no" value="<?php echo e($data_detail->transaction_no); ?>"><button class="btn-transparent"><?php echo e($data_detail->transaction_no); ?></button></form></td>
                  <td><?php echo e($charge); ?>.00</td>
                  <td><?php echo e(number_format($order_price)); ?>.00</td>
                  <td><?php echo e($account_statement); ?></td>
                  <td><form target="_blank" action="<?php echo e(route('printFinance')); ?>" method="POST"><?php echo csrf_field(); ?><input type="hidden" name="vendor_id" value="<?php echo e($id); ?>"><input type="hidden" name="transaction_no" value="<?php echo e($data_detail->transaction_no); ?>"><button class="btn-transparent"><i class="fa fa-print"></i> Print</button></form></td>
               </tr>
               <tr>
                  <td colspan="12" class="hiddenRow">
                     <div class="accordian-body collapse" id="demo<?php echo e($order_detail->order_no); ?>">
                        <table class="table table-striped">
                           <thead>                              
                              <tr>
                                 <th>Product Name</th>
                                 <th>Color</th>
                                 <th>Size</th>
                                 <th>User</th>
                                 <th>Quantity</th>
                                 <th>Total</th>
                              </tr>
                           </thead>
                           <tbody>
                             <?php
                             $data= App\Models\Order::with(['vendor_products' => function($query) use ($id) {
                                $query->whereHas('products', function ($query) use ($id) {
                                      $query->where('vendor_id', $id);
                                  });
                              }])->where('order_no',$order_detail->order_no)->first();
                             ?>
                             <?php if(!empty($data->vendor_products)): ?>
                              <?php $__currentLoopData = $data->vendor_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($prod_list->products->name); ?></td>
                                  <td><?php echo e(@$prod_list->colorInfo->name); ?></td>
                                  <td><?php echo e(@$prod_list->sizeInfo->name); ?></td>
                                  <td><?php echo e(@$prod_list->userDetail->name); ?></td>
                                  <td><?php echo e($prod_list->quantity); ?></td>
                                  <td><?php echo e(number_format(@$prod_list->price * @$prod_list->quantity)); ?></td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                           </tbody>
                        </table>
                     </div>
                  </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $total = $order_price + $total; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         </table>
         <br><strong>Total Transaction: <?php echo e(number_format($total)); ?>.00
      </div>      
   </div>
</div>

<?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/admin/pages/finance_table.blade.php ENDPATH**/ ?>