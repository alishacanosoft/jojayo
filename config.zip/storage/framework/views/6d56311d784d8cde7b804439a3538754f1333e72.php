<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<style>
    .same-row{
        display:inline-flex;
    }
    .same-row label{
        margin-right: 5px;
        padding-top: 5px;
    }    
    table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
    }

    td, th {
    border-right: 1px solid #dddddd;
    border-left: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
    }

    button.transparent {
        background: transparent;
        border: none;
        cursor: pointer;
    }     
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-lg-12">
        <div class="row">
            <!--<input type="text" name="daterange" value="01/01/2018 - 01/15/2018" />-->
            <?php
            $vendor_id = App\Models\Vendor::where('user_id', \Auth::user()->id)->first();
            ?>
            <div class="form-group <?php if(!Auth::user()->admin()): ?> hidden <?php endif; ?>">
                 <div class="col-md-4 col-lg-4 same-row" style="padding-top:5px">
                    <label>Supplier</label>
                    <select name="vendor_id" id="vendor_id" class="requires form-control">
                        <option selected disabled>--Select Vendor--</option>
                        <?php if(!empty($all_vendor)): ?>
                        <?php $__currentLoopData = $all_vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vendor_list->id); ?>" <?php if($vendor_list->id == @$vendor_id->id): ?> selected <?php endif; ?>><?php echo e($vendor_list->company); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                 </div>
            </div>
            
            <div class="form-group">
                 <div class="col-md-4 col-lg-4 same-row">
                    <label>Period</label>
                    <select name="date" id="date" class="requires form-control">
                        <option selected disabled>--Select Transaction Date--</option>
                    </select>
                 </div>
            </div>
            
        </div>
        <br><hr style="border-top: 1px solid #ffffff;"><br>    
    </div>
</div>
<section id="invoice"></section>
<?php $__env->startSection('scripts'); ?>
<script>
var admin = "<?php echo e(Auth::user()->roles); ?>";
if(admin == 'admin'){
    admin = 'yes';
} else {
    admin = 'no';
}
if (admin == 'no'){
    var vendor_id = $('#vendor_id').find(":selected").val();
    $.ajax({
        url: "/auth/get_vendor_data/"+vendor_id,
        success: function(response){
            $('#date').html(response);
        }
    })
}
$('#vendor_id').on('change', function(){
    var vendor_id = $(this).val();
    $.ajax({
        url: "/auth/get_vendor_data/"+vendor_id,
        success: function(response){
            $('#date').html(response);             
        }
    })
})

$('#date').on('change', function(){
    var vendor_id = $('#vendor_id').find(":selected").val();
    var date = $(this).val();
    $.ajax({
        url: "/auth/get_statement/"+vendor_id+"/"+date,
        success: function(response){
            $('#invoice').html(response);
        }
    })
})

$(document).on('click','.btn-default', function(){
    var icon = $(this).find('span').attr('class');
    if(icon == 'fa fa-plus'){
        $(this).find('span').attr('class', 'fa fa-minus');
    } else {
        $(this).find('span').attr('class', 'fa fa-plus');
    }
})
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/admin/pages/statement.blade.php ENDPATH**/ ?>