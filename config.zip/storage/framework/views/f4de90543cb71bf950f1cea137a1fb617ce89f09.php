<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-lg-12">
      <div class="row">
         <div class="col-sm-12">
            <div class="nav-tabs-custom">
               <ul class="nav nav-tabs">
                  <li class="<?php if($active_tab == 'manage'): ?> active <?php endif; ?>"><a href="#manage" data-toggle="tab">All Areas</a></li>
                  <li class="<?php if($active_tab == 'create'): ?> active <?php endif; ?>"><a href="#create" data-toggle="tab">New Area</a></li>
                  <input type="hidden" id="base" value="<?php echo e(route('ajax.categories')); ?>">
               </ul>
               <div class="tab-content bg-white">
                  <div class="tab-pane <?php if($active_tab == 'manage'): ?> active <?php endif; ?>" id="manage">
                     <div class="table-responsive">
                     <table class="table table-striped table-bordered nowrap datatable_action" role="grid" aria-describedby="basic-col-reorder_info">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>City name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($area_lists)): ?> <?php $__currentLoopData = $area_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_areas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($all_areas->name); ?></td>
                                <td><?php echo e($all_areas->City->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('areas.edit', $all_areas->id)); ?>" class="btn btn-primary btn-xs pull-left" style="margin-right: 5px">
                                        <i class="fa fa-pencil-square-o"></i>
                                    </a>
                                    <a class="pull-left" onclick="return confirm('Are you sure you want to delete this user?')">
                                        <form method="POST" action="<?php echo e(route('areas.destroy', $all_areas->id)); ?>" accept-charset="UTF-8">
                                            <input name="_method" type="hidden" value="DELETE">
                                            <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                            <button class="btn btn-danger btn-xs" type="submit"><i class="fa fa-trash-o"></i></button>
                                        </form>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                     </div>
                  </div>
                  <div class="tab-pane <?php if($active_tab == 'create'): ?> active <?php endif; ?>" id="create">
                  <?php if(!empty($data)): ?>
                        <?php echo e(Form::open(['url'=>route('areas.update', $data->id), 'class'=>'form', 'id'=>'area_add', 'files'=>true,'method'=>'patch'])); ?>

                    <?php else: ?>
                        <form action="<?php echo e(route('areas.store')); ?>" method="POST">
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <div class="page-body">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <h5>Add Area</h5>
                                                <div class="card-header-right">
                                                    <i class="icofont icofont-rounded-down"></i>
                                                    <i class="icofont icofont-refresh"></i>
                                                    <i class="icofont icofont-close-circled"></i>
                                                </div>
                                            </div>
                                            <div class="card-block">
                                                <div class="form-group row">
                                                    <div class="col-sm-12">
                                                        <input type="text" class="form-control" value="<?php echo e(@$data->name); ?>" name="name" id="name" placeholder="Name of the city">
                                                        <?php if($errors->has('name')): ?>
                                                        <span class='validation-errors text-danger'><?php echo e($errors->first('name')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <div class="col-sm-12">
                                                        <select class="form-control" name="city_id">
                                                          <option selected disabled>--Select Region--</option>
                                                          <?php if(!empty($all_cities)): ?>
                                                              <?php $__currentLoopData = $all_cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                  <option value="<?php echo e($city_list->id); ?>" <?php if(@$data->city_id == $city_list->id): ?> selected <?php endif; ?>><?php echo e($city_list->name); ?></option>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                          <?php endif; ?>
                                                        </select>
                                                        <?php if($errors->has('city_id')): ?>
                                                        <span class='validation-errors text-danger'><?php echo e($errors->first('city_id')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <div class="col-sm-12">
                                                        <input type="text" class="form-control" value="<?php echo e(@$data->delivery_charge); ?>" name="delivery_charge" id="delivery_charge" placeholder="Delivery charge">
                                                        <?php if($errors->has('delivery_charge')): ?>
                                                        <span class='validation-errors text-danger'><?php echo e($errors->first('delivery_charge')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <div class="col-sm-12">
                                                        <input type="text" class="form-control" value="<?php echo e(@$data->express_charge); ?>" name="express_charge" id="express_charge" placeholder="Express delivery charge">
                                                        <?php if($errors->has('express_charge')): ?>
                                                        <span class='validation-errors text-danger'><?php echo e($errors->first('express_charge')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <div class="col-sm-12">
                                                      <button type="submit" class="btn btn-danger m-b-0 pull-right ml-2">Save</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('#add_row').hide();
    $('#new').on('click', function() {
        $('#add_row').slideDown(1000);
        $('#new').hide("slide", {
            direction: "right"
        }, 1000);
    });
    $('.edit').on('click', function() {
        let id = $(this).attr("value");
        var editurl = '<?php echo e(route("ads.edit", ":data")); ?>';
        var link = '<?php echo e(route("ads.update", ":data")); ?>';
        editurl = editurl.replace(':data', id);
        link = link.replace(':data', id);
        $.ajax({
            url: editurl,
            dataType: 'json',
            data: {
                id: id
            },
            success: function(response) {
                $('#name').val(response.title);
                $('#link').val(response.url);
                $('#start_date').val(response.start_date);
                $('#end_date').val(response.end_date);
                $('#thumbnail').val(response.image);
                $('#holder').attr('src', response.image);
                $('form').attr('action', link);
                $('#add').text('Update Ads');
                $('input:hidden').after('<input name="_method" type="hidden" value="PATCH">');
                $('#add_row').slideDown(1000);
                $('#new').hide("slide", {
                    direction: "right"
                }, 1000);
            },
        });
    });
    $('#discard').on('click', function() {
        $('#add_row').slideUp(1000);
        $('#new').show("slide", {
            direction: "right"
        }, 1000);
    })
</script>
<?php echo $__env->make('admin.scripts.post_category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/admin/pages/areas.blade.php ENDPATH**/ ?>