 <?php $__env->startSection('content'); ?>
<div class="ps-breadcrumb">
    <div class="ps-container">
    <ul class="breadcrumb">
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li><a href="<?php echo e(url('/blogs')); ?>">Blogs</a></li>
        <li><?php echo e(ucwords($singleBlog->title)); ?></li>
    </ul>
    </div>
</div>
<div class="ps-page--blog">
         <div class="ps-post--detail ps-post--parallax">
        <div class="ps-post__header bg--parallax" data-background="<?php echo e(asset('/uploads/blogs/'.$singleBlog->image)); ?>">
          <div class="container">
            <h4><?php echo e(ucwords($singleBlog->category->name)); ?></h4>
            <h1><?php echo e(ucwords($singleBlog->title)); ?></h1>
            <p><?php echo e($singleBlog->created_at->format('F  j, Y')); ?></p>
          </div>
        </div>
        <div class="container">
          <div class="ps-post__content">
            <p> <?php echo $singleBlog->description; ?> </p>
          </div>
          <div class="ps-post__footer">
            <div class="ps-post__social">
              <a class="facebook" value="<?php echo e($singleBlog->id); ?>" onclick='fbShare("<?php echo e(URL('/')); ?>/<?php echo e($singleBlog->slug); ?>")'><i class="fa fa-facebook"></i></a>
              <a class="twitter" value="<?php echo e($singleBlog->id); ?>" onclick='twitShare("<?php echo e(URL('/')); ?>/<?php echo e($singleBlog->slug); ?>","<?php echo e($singleBlog->title); ?>")'><i class="fa fa-twitter"></i></a>
              <a class="whatsapp" value="<?php echo e($singleBlog->id); ?>" onclick='whatsappShare("<?php echo e(URL('/')); ?>/<?php echo e($singleBlog->slug); ?>","<?php echo e($singleBlog->title); ?>")'><i class="fa fa-whatsapp"></i></a>
              <a class="google" value="<?php echo e($singleBlog->id); ?>" href="mailto:?subject=<?php echo e($singleBlog->title); ?>...&amp;body=<?php echo shortContent($singleBlog->description, 20); ?>...<?php echo e(URL('/')."/".$singleBlog->slug); ?>"><i class="fa fa-envelope"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="ps-related-posts">
          <h3>Related Posts</h3>
          <div class="row">
          <?php if(!empty($relatedBlogs)): ?> 
          <?php $__currentLoopData = $relatedBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12 ">
                <div class="ps-post">
                <div class="ps-post__thumbnail"><a class="ps-post__overlay" href="<?php echo e(url('/blogs/'.$post->slug)); ?>"></a><img src="<?php echo e(asset('/uploads/blogs/'.$singleBlog->image)); ?>" alt="<?php echo e($post->slug); ?>">
                    <?php if($post->feature==1): ?>
                    <div class="ps-post__badge"><i class="icon-star"></i></div>
                    <?php endif; ?>
                </div>
                <div class="ps-post__content">
                    <div class="ps-post__top">
                    <div class="ps-post__meta"><a href="<?php echo e(url('/blogs/categories/'.$post->category->slug)); ?>"><?php echo e(ucwords($post->category->name)); ?></a>
                    </div><a class="ps-post__title" href="<?php echo e(url('/blogs/'.$post->slug)); ?>"><?php echo e(ucwords($post->title)); ?></a>
                    </div>
                    <div class="ps-post__bottom">
                    <p><?php echo e($post->created_at->format('F  j, Y')); ?></p>
                    </div>
                </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
          </div>
        </div>
      </div>
</div>

<div class="related-products"></div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
function fbShare(url) {
  window.open("https://www.facebook.com/sharer/sharer.php?u=" + url, "_blank", "toolbar=no, scrollbars=yes, resizable=yes, top=200, left=500, width=600, height=400");
}
function twitShare(url, title) {
    window.open("https://twitter.com/intent/tweet?text=" + encodeURIComponent(title) + "+" + url + " via @jojayo", "_blank", "toolbar=no, scrollbars=yes, resizable=yes, top=200, left=500, width=600, height=400");
}
function whatsappShare(url, title) {
    message = title + " " + url;
    window.open("https://api.whatsapp.com/send?text=" + message);
}
function googleplusShare(url) {
    window.open("https://plus.google.com/share?url=" + url, "_blank", "toolbar=no, scrollbars=yes, resizable=yes, top=200, left=500, width=600, height=400");
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/frontend/pages/blog-single.blade.php ENDPATH**/ ?>