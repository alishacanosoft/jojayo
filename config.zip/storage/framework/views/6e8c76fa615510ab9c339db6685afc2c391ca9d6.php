<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-lg-12">
      <div class="row">
        <div class="col-lg-4">
        <div class="form-group">
            <label>Name</label>
            <input class="form-control" type="text" name="name" required="" id="name">
        </div>
        <input type="submit" name="submit" value="Add New Method" class="btn btn-primary" id="submit" style="margin-bottom: 20px">
        </div>
         <div class="col-sm-8">
            <div class="panel panel-custom ">
                <header class="panel-heading">All payment methods</header>
                <div class="panel-body">
                <table id="basic-col-reorder" class="table table-striped table-bordered nowrap dataTable" role="grid" aria-describedby="basic-col-reorder_info">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody id="check">
                    <?php if(!empty($allmethods)): ?>
                        <?php $__currentLoopData = $allmethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $paymentList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="<?php echo e($paymentList->id); ?>">
                                <input type="hidden" value="<?php echo e($paymentList->id); ?>">
                                <td><?php echo e($paymentList->name); ?></td>
                                <td><a href="<?php echo e(route('payments.edit', $paymentList->id)); ?>"><button type="button" class="btn btn-primary btn-xs waves-effect waves-light" style="float: none;"><i class="fa fa-pencil-square-o"></i></button></a><button type="button" class="btn-xs btn btn-danger waves-effect waves-light table-delete" style="float: none;margin: 5px;" data-target="#sign-in-modal"><i class="fa fa-trash-o"></i></button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/admin/pages/methods.blade.php ENDPATH**/ ?>