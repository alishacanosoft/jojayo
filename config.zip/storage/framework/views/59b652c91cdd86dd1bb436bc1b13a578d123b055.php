<?php $__env->startSection('content'); ?>
<div class="ps-page--404">
   <div class="container">
      <div class="ps-section__content"><img src="<?php echo e(asset('/frontend/images/404.jpg')); ?>" alt="jojayo-404">
            <h3>ohh! page not found</h3>
            <p>It seems we can't find what you're looking for. Perhaps searching can help or go back to<a href="<?php echo e(url('/')); ?>"> Homepage</a></p>
           
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\jojayo\resources\views/errors/404.blade.php ENDPATH**/ ?>