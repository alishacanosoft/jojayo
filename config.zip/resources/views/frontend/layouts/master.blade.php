@include('frontend.partials.header')
@yield('content')
@include('frontend.partials.footer')